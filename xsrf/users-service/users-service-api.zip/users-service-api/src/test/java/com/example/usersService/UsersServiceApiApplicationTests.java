package com.example.usersService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersServiceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
