package com.example.usersService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UsersServiceApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(UsersServiceApiApplication.class, args);
	}

}
